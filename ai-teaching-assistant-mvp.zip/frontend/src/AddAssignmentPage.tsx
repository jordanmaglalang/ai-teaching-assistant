export default function AddAssignmentPage() {
    return <h1>Add Assignment Page</h1>;
}